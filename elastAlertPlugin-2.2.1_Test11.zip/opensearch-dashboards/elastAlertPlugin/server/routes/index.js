"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@osd/config-schema");

function defineRoutes(router) {
  router.get({
    path: '/api/elast_alert_plugin/example',
    validate: false
  }, async (context, request, response) => {
    return response.ok({
      body: {
        time: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/currentuser',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: 'app-settings',
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/internaluser',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      resp = await context.core.opensearch.client.asInternalUser.search({
        index: 'app-settings',
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.post({
    path: '/api/elast_alert_plugin/cats',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      console.log('aa'); // resp = await context.core.opensearch.client.asCurrentUser.cat.indices();
      // resp = await context.core.opensearch.client.asCurrentUser.security.getRole();

      resp = await context.core.opensearch.client.asCurrentUser.security.getUser();
      console.log(resp);
    } catch (errResp) {
      console.log('bb');
      console.log(errResp);
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/test_user',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      console.log('aa');
      resp = await context.core.opensearch.client; // // resp = await context.core.opensearch.client.asCurrentUser.security.getRole();
      // resp = await context.core.opensearch.client.asCurrentUser.security.getUser();
      // console.log(resp);
    } catch (errResp) {
      console.log('bb');
      console.log(errResp);
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/path',
    validate: false
  }, async (context, request, response) => {
    const {
      id
    } = request.params;
    const params = {
      emailGroupId: id
    };
    console.log(request.url.query.avc);
    console.log('fdfdxxxxxxxxxxxxxxxxxxxx');
    console.log(params); // const { detectorId } = request.params;
    // const { detectorId } = request.params;
    // const params = { emailGroupId: detectorId };
    // const format = request.params;
    // var format = params;
    //  type = request.params.type;

    var format = 'cddd';
    return response.ok({
      body: {
        entry: format
      }
    });
  }); //   router.get(
  //     {
  //       path: '/api/elast_alert_plugin/as_current_user/check_index',
  //       validate: false,
  //     },
  //     async (context, request, response) => {
  //       let resp = {}
  //       try {
  //         console.log(request);
  //         // console.log(abc); 
  //         // console.log(request.url.query.index_name);
  //         // console.log('fdfdxxxxxxxxxxxxxxxxxxxx');
  //         // let indexName = request.url.query.index_name;
  //         // indexName='app-settings';
  //         console.log(request.url.search); 
  //         let text = request.url.search;
  // const myArray = text.split("=");
  // let index_name = myArray[1];
  // console.log(index_name); 
  //         resp = await context.core.opensearch.client.asCurrentUser.search({
  //           index: index_name,
  //           body: {
  //             query: {
  //               "match_all": {}
  //             },
  //             size: 100
  //           }
  //         })
  //       } catch (errResp) {
  //         resp = errResp
  //       }
  //       return response.ok({ body: resp });
  //     }
  //   );

  router.get({
    path: '/api/elast_alert_plugin/as_current_user/check_index/{id}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request.params.id);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      console.log(request); // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];

      let index_name = request.params.id;
      console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: index_name,
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/indices',
    validate: false // validate: {
    //   params: schema.object({
    //     id: schema.string(),
    //     // name: schema.string(),
    //   }),
    // },

  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.cat.indices();
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/plugins',
    validate: false // validate: {
    //   params: schema.object({
    //     id: schema.string(),
    //     // name: schema.string(),
    //   }),
    // },

  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.cat.plugins();
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImdldCIsInBhdGgiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJvayIsImJvZHkiLCJ0aW1lIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicmVzcCIsImNvcmUiLCJvcGVuc2VhcmNoIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsInNlYXJjaCIsImluZGV4IiwicXVlcnkiLCJzaXplIiwiZXJyUmVzcCIsImFzSW50ZXJuYWxVc2VyIiwicG9zdCIsImNvbnNvbGUiLCJsb2ciLCJzZWN1cml0eSIsImdldFVzZXIiLCJpZCIsInBhcmFtcyIsImVtYWlsR3JvdXBJZCIsInVybCIsImF2YyIsImZvcm1hdCIsImVudHJ5Iiwic2NoZW1hIiwib2JqZWN0Iiwic3RyaW5nIiwiaW5kZXhfbmFtZSIsImNhdCIsImluZGljZXMiLCJwbHVnaW5zIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQ0E7O0FBQ08sU0FBU0EsWUFBVCxDQUFzQkMsTUFBdEIsRUFBdUM7QUFDNUNBLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxpQ0FEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFdBQU9BLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQ2pCQyxNQUFBQSxJQUFJLEVBQUU7QUFDSkMsUUFBQUEsSUFBSSxFQUFFLElBQUlDLElBQUosR0FBV0MsV0FBWDtBQURGO0FBRFcsS0FBWixDQUFQO0FBS0QsR0FYSDtBQWFBWCxFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUscUNBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQU9FLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxRQUFJTSxJQUFJLEdBQUcsRUFBWDs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDQyxNQUE3QyxDQUFvRDtBQUMvREMsUUFBQUEsS0FBSyxFQUFFLGNBRHdEO0FBRS9EVixRQUFBQSxJQUFJLEVBQUU7QUFDSlcsVUFBQUEsS0FBSyxFQUFFO0FBQ0wseUJBQWE7QUFEUixXQURIO0FBSUpDLFVBQUFBLElBQUksRUFBRTtBQUpGO0FBRnlELE9BQXBELENBQWI7QUFTRCxLQVZELENBVUUsT0FBT0MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBdkJIO0FBeUJBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsc0NBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUVwQyxRQUFJTSxJQUFJLEdBQUcsRUFBWDs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JPLGNBQS9CLENBQThDTCxNQUE5QyxDQUFxRDtBQUNoRUMsUUFBQUEsS0FBSyxFQUFFLGNBRHlEO0FBRWhFVixRQUFBQSxJQUFJLEVBQUU7QUFDSlcsVUFBQUEsS0FBSyxFQUFFO0FBQ0wseUJBQWE7QUFEUixXQURIO0FBSUpDLFVBQUFBLElBQUksRUFBRTtBQUpGO0FBRjBELE9BQXJELENBQWI7QUFTRCxLQVZELENBVUUsT0FBT0MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBdEJIO0FBd0JBWixFQUFBQSxNQUFNLENBQUN1QixJQUFQLENBQ0U7QUFDRXJCLElBQUFBLElBQUksRUFBRSw4QkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBT0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFFBQUlNLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWixFQURFLENBR0Y7QUFDQTs7QUFFQWIsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkNVLFFBQTdDLENBQXNEQyxPQUF0RCxFQUFiO0FBQ0FILE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYixJQUFaO0FBR0QsS0FWRCxDQVVFLE9BQU9TLE9BQVAsRUFBZ0I7QUFDaEJHLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFDQUQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlKLE9BQVo7QUFDQVQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBRUQ7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBMUJIO0FBNkJBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsbUNBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQU9FLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxRQUFJTSxJQUFJLEdBQUcsRUFBWDs7QUFDQSxRQUFJO0FBQ0ZZLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFFQWIsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUFyQyxDQUhFLENBSUY7QUFFQTtBQUNBO0FBR0QsS0FWRCxDQVVFLE9BQU9NLE9BQVAsRUFBZ0I7QUFDaEJHLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFDQUQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlKLE9BQVo7QUFDQVQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBRUQ7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBMUJIO0FBOEJBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsOEJBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNO0FBQUVzQixNQUFBQTtBQUFGLFFBQVN2QixPQUFPLENBQUN3QixNQUF2QjtBQUNBLFVBQU1BLE1BQU0sR0FBRztBQUFFQyxNQUFBQSxZQUFZLEVBQUVGO0FBQWhCLEtBQWY7QUFDQUosSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFPLENBQUMwQixHQUFSLENBQVlaLEtBQVosQ0FBa0JhLEdBQTlCO0FBQ0FSLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDBCQUFaO0FBQ0FELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxNQUFaLEVBTG9DLENBTXBDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxRQUFJSSxNQUFNLEdBQUcsTUFBYjtBQUNBLFdBQU8zQixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUNqQkMsTUFBQUEsSUFBSSxFQUFFO0FBQ0owQixRQUFBQSxLQUFLLEVBQUVEO0FBREg7QUFEVyxLQUFaLENBQVA7QUFLRCxHQXZCSCxFQTFINEMsQ0FxSjVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBakMsRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLDBEQURSO0FBRUU7QUFDQUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1IwQixNQUFBQSxNQUFNLEVBQUVNLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJSLFFBQUFBLEVBQUUsRUFBRU8scUJBQU9FLE1BQVAsRUFEZ0IsQ0FFcEI7O0FBRm9CLE9BQWQ7QUFEQTtBQUhaLEdBREYsRUFhRSxPQUFPakMsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDa0IsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksdUVBQVo7QUFDQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFPLENBQUN3QixNQUFSLENBQWVELEVBQTNCO0FBQ0FKLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJFQUFaLEVBSG9DLENBSXBDO0FBQ0E7QUFDQTs7QUFDQSxRQUFJYixJQUFJLEdBQUcsRUFBWDs7QUFDQSxRQUFJO0FBQ0ZZLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBWixFQURFLENBRUY7QUFDQTtBQUNBOztBQUVBLFVBQUlpQyxVQUFVLEdBQUdqQyxPQUFPLENBQUN3QixNQUFSLENBQWVELEVBQWhDO0FBQ0FKLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYSxVQUFaO0FBQ0ExQixNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2Q0MsTUFBN0MsQ0FBb0Q7QUFDL0RDLFFBQUFBLEtBQUssRUFBRW9CLFVBRHdEO0FBRS9EOUIsUUFBQUEsSUFBSSxFQUFFO0FBQ0pXLFVBQUFBLEtBQUssRUFBRTtBQUNMLHlCQUFhO0FBRFIsV0FESDtBQUlKQyxVQUFBQSxJQUFJLEVBQUU7QUFKRjtBQUZ5RCxPQUFwRCxDQUFiO0FBU0QsS0FqQkQsQ0FpQkUsT0FBT0MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBMUNIO0FBc0RBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsaURBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFLEtBRlosQ0FHRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBUkYsR0FERixFQWFFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQ2tCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVFQUFaO0FBQ0FELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBWjtBQUNBbUIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMkVBQVosRUFIb0MsQ0FJcEM7QUFDQTtBQUNBOztBQUNBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUlBLFFBQUk7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQUEsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkN1QixHQUE3QyxDQUFpREMsT0FBakQsRUFBYjtBQUNBaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVliLElBQVo7QUFDRCxLQVZELENBVUUsT0FBT1MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBdENIO0FBeUNBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsaURBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFLEtBRlosQ0FHRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBUkYsR0FERixFQWFFLE9BQU9DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQ2tCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVFQUFaO0FBQ0FELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBWjtBQUNBbUIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMkVBQVosRUFIb0MsQ0FJcEM7QUFDQTtBQUNBOztBQUNBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUlBLFFBQUk7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQUEsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkN1QixHQUE3QyxDQUFpREUsT0FBakQsRUFBYjtBQUNBakIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVliLElBQVo7QUFDRCxLQVZELENBVUUsT0FBT1MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBdENIO0FBeUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vZXhhbXBsZScsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICB0aW1lOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2N1cnJlbnR1c2VyJyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuXG5cbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiAnYXBwLXNldHRpbmdzJyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBcIm1hdGNoX2FsbFwiOiB7fVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNpemU6IDEwMFxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgcmVzcCA9IGVyclJlc3BcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9pbnRlcm5hbHVzZXInLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG5cbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogJ2FwcC1zZXR0aW5ncycsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2NhdHMnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG5cblxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgbGV0IHJlc3AgPSB7fVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc29sZS5sb2coJ2FhJyk7XG5cbiAgICAgICAgLy8gcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmNhdC5pbmRpY2VzKCk7XG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWN1cml0eS5nZXRSb2xlKCk7XG5cbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlY3VyaXR5LmdldFVzZXIoKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG5cblxuICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAgICAgICBjb25zb2xlLmxvZygnYmInKTtcbiAgICAgICAgY29uc29sZS5sb2coZXJyUmVzcCk7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG5cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL3Rlc3RfdXNlcicsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBsZXQgcmVzcCA9IHt9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zb2xlLmxvZygnYWEnKTtcblxuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50O1xuICAgICAgICAvLyAvLyByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuc2VjdXJpdHkuZ2V0Um9sZSgpO1xuXG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWN1cml0eS5nZXRVc2VyKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3ApO1xuXG5cbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgY29uc29sZS5sb2coJ2JiJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGVyclJlc3ApO1xuICAgICAgICByZXNwID0gZXJyUmVzcFxuXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL3BhdGgnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAgICAgY29uc29sZS5sb2cocmVxdWVzdC51cmwucXVlcnkuYXZjKTtcbiAgICAgIGNvbnNvbGUubG9nKCdmZGZkeHh4eHh4eHh4eHh4eHh4eHh4eHgnKTtcbiAgICAgIGNvbnNvbGUubG9nKHBhcmFtcyk7XG4gICAgICAvLyBjb25zdCB7IGRldGVjdG9ySWQgfSA9IHJlcXVlc3QucGFyYW1zO1xuICAgICAgLy8gY29uc3QgeyBkZXRlY3RvcklkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBkZXRlY3RvcklkIH07XG4gICAgICAvLyBjb25zdCBmb3JtYXQgPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIHZhciBmb3JtYXQgPSBwYXJhbXM7XG4gICAgICAvLyAgdHlwZSA9IHJlcXVlc3QucGFyYW1zLnR5cGU7XG4gICAgICB2YXIgZm9ybWF0ID0gJ2NkZGQnO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIGVudHJ5OiBmb3JtYXRcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIC8vICAgcm91dGVyLmdldChcbiAgLy8gICAgIHtcbiAgLy8gICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2FzX2N1cnJlbnRfdXNlci9jaGVja19pbmRleCcsXG4gIC8vICAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgLy8gICAgIH0sXG5cblxuICAvLyAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gIC8vICAgICAgIGxldCByZXNwID0ge31cbiAgLy8gICAgICAgdHJ5IHtcbiAgLy8gICAgICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyhhYmMpOyBcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXF1ZXN0LnVybC5xdWVyeS5pbmRleF9uYW1lKTtcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZygnZmRmZHh4eHh4eHh4eHh4eHh4eHh4eHh4Jyk7XG4gIC8vICAgICAgICAgLy8gbGV0IGluZGV4TmFtZSA9IHJlcXVlc3QudXJsLnF1ZXJ5LmluZGV4X25hbWU7XG4gIC8vICAgICAgICAgLy8gaW5kZXhOYW1lPSdhcHAtc2V0dGluZ3MnO1xuICAvLyAgICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QudXJsLnNlYXJjaCk7IFxuICAvLyAgICAgICAgIGxldCB0ZXh0ID0gcmVxdWVzdC51cmwuc2VhcmNoO1xuICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIj1cIik7XG4gIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVsxXTtcbiAgLy8gY29uc29sZS5sb2coaW5kZXhfbmFtZSk7IFxuICAvLyAgICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xuICAvLyAgICAgICAgICAgaW5kZXg6IGluZGV4X25hbWUsXG4gIC8vICAgICAgICAgICBib2R5OiB7XG4gIC8vICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gIC8vICAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgLy8gICAgICAgICAgICAgfSxcbiAgLy8gICAgICAgICAgICAgc2l6ZTogMTAwXG4gIC8vICAgICAgICAgICB9XG4gIC8vICAgICAgICAgfSlcbiAgLy8gICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAvLyAgICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gIC8vICAgICAgIH1cbiAgLy8gICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzcCB9KTtcbiAgLy8gICAgIH1cbiAgLy8gICApO1xuXG5cblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvY2hlY2tfaW5kZXgve2lkfScsXG4gICAgICAvLyB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0LnBhcmFtcy5pZCk7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gZW5kICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgLy8gY29uc3QgeyBpZCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGlkKTtcbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICAvLyBsZXQgdGV4dCA9IHJlcXVlc3QudXJsLnBhdGhuYW1lO1xuICAgICAgICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIi9cIik7XG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVs1XTtcblxuICAgICAgICBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICBjb25zb2xlLmxvZyhpbmRleF9uYW1lKTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IGluZGV4X25hbWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG5cblxuXG5cblxuXG5cblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvaW5kaWNlcycsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICAvLyB2YWxpZGF0ZToge1xuICAgICAgLy8gICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgLy8gICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAvLyAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgLy8gICB9KSxcbiAgICAgIC8vIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICAvLyBjb25zdCB7IGlkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAgICAgLy8gY29uc29sZS5sb2coaWQpO1xuICAgICAgbGV0IHJlc3AgPSB7fVxuXG5cbiAgICAgIFxuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVxdWVzdCk7XG4gICAgICAgIC8vIGxldCB0ZXh0ID0gcmVxdWVzdC51cmwucGF0aG5hbWU7XG4gICAgICAgIC8vIGNvbnN0IG15QXJyYXkgPSB0ZXh0LnNwbGl0KFwiL1wiKTtcbiAgICAgICAgLy8gbGV0IGluZGV4X25hbWUgPSBteUFycmF5WzVdO1xuXG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gcmVxdWVzdC5wYXJhbXMuaWQ7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGluZGV4X25hbWUpO1xuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuY2F0LmluZGljZXMoKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvcGx1Z2lucycsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICAvLyB2YWxpZGF0ZToge1xuICAgICAgLy8gICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgLy8gICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAvLyAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgLy8gICB9KSxcbiAgICAgIC8vIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICAvLyBjb25zdCB7IGlkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAgICAgLy8gY29uc29sZS5sb2coaWQpO1xuICAgICAgbGV0IHJlc3AgPSB7fVxuXG5cbiAgICAgIFxuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gY29uc29sZS5sb2cocmVxdWVzdCk7XG4gICAgICAgIC8vIGxldCB0ZXh0ID0gcmVxdWVzdC51cmwucGF0aG5hbWU7XG4gICAgICAgIC8vIGNvbnN0IG15QXJyYXkgPSB0ZXh0LnNwbGl0KFwiL1wiKTtcbiAgICAgICAgLy8gbGV0IGluZGV4X25hbWUgPSBteUFycmF5WzVdO1xuXG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gcmVxdWVzdC5wYXJhbXMuaWQ7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGluZGV4X25hbWUpO1xuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuY2F0LnBsdWdpbnMoKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxufVxuIl19