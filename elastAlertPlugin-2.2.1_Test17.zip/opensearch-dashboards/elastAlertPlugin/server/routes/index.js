"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@osd/config-schema");

function defineRoutes(router) {
  router.get({
    path: '/api/elast_alert_plugin/example',
    validate: false
  }, async (context, request, response) => {
    return response.ok({
      body: {
        time: new Date().toISOString()
      }
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/currentuser',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: 'app-settings',
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/internaluser',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      resp = await context.core.opensearch.client.asInternalUser.search({
        index: 'app-settings',
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.post({
    path: '/api/elast_alert_plugin/cats',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      console.log('aa'); // resp = await context.core.opensearch.client.asCurrentUser.cat.indices();
      // resp = await context.core.opensearch.client.asCurrentUser.security.getRole();

      resp = await context.core.opensearch.client.asCurrentUser.security.getUser();
      console.log(resp);
    } catch (errResp) {
      console.log('bb');
      console.log(errResp);
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/test_user',
    validate: false
  }, async (context, request, response) => {
    let resp = {};

    try {
      console.log('aa');
      resp = await context.core.opensearch.client; // // resp = await context.core.opensearch.client.asCurrentUser.security.getRole();
      // resp = await context.core.opensearch.client.asCurrentUser.security.getUser();
      // console.log(resp);
    } catch (errResp) {
      console.log('bb');
      console.log(errResp);
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/path',
    validate: false
  }, async (context, request, response) => {
    const {
      id
    } = request.params;
    const params = {
      emailGroupId: id
    };
    console.log(request.url.query.avc);
    console.log('fdfdxxxxxxxxxxxxxxxxxxxx');
    console.log(params); // const { detectorId } = request.params;
    // const { detectorId } = request.params;
    // const params = { emailGroupId: detectorId };
    // const format = request.params;
    // var format = params;
    //  type = request.params.type;

    var format = 'cddd';
    return response.ok({
      body: {
        entry: format
      }
    });
  }); //   router.get(
  //     {
  //       path: '/api/elast_alert_plugin/as_current_user/check_index',
  //       validate: false,
  //     },
  //     async (context, request, response) => {
  //       let resp = {}
  //       try {
  //         console.log(request);
  //         // console.log(abc); 
  //         // console.log(request.url.query.index_name);
  //         // console.log('fdfdxxxxxxxxxxxxxxxxxxxx');
  //         // let indexName = request.url.query.index_name;
  //         // indexName='app-settings';
  //         console.log(request.url.search); 
  //         let text = request.url.search;
  // const myArray = text.split("=");
  // let index_name = myArray[1];
  // console.log(index_name); 
  //         resp = await context.core.opensearch.client.asCurrentUser.search({
  //           index: index_name,
  //           body: {
  //             query: {
  //               "match_all": {}
  //             },
  //             size: 100
  //           }
  //         })
  //       } catch (errResp) {
  //         resp = errResp
  //       }
  //       return response.ok({ body: resp });
  //     }
  //   );

  router.get({
    path: '/api/elast_alert_plugin/as_current_user/check_index/{id}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request.params.id);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      console.log(request); // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];

      let index_name = request.params.id;
      console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: index_name,
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/check_index_array/{id}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('xxxxxxxxxxxxxxxxxxxxxx ************************************************');
    console.log(request.params.id);
    console.log('yyyyyyyyyyyyyyyyy end ************************************************');
    let resp = {};

    try {
      console.log(request);
      let index_name = request.params.id;
      index_name = 'license,app-settings';
      console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: index_name,
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.post({
    path: '/api/elast_alert_plugin/as_current_user/check_index_object',
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    console.log('xxxxxxxxxxxxxxxxxxxxxx ************************************************');
    const arrayOfIndices = request.body.asArray;
    console.log(arrayOfIndices); // console.log(arrayOfIndices[1]);

    console.log('yyyyyyyyyyyyyyyyy end ************************************************');
    let resp = {};

    try {
      console.log(request); // let index_name = request.params.id;
      // index_name='license,app-settings';
      // console.log(index_name);

      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: arrayOfIndices,
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.post({
    path: '/api/elast_alert_plugin/as_current_user/check_object',
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    console.log('VVVVVxxxxxxxxxxxxxxxxxxxxxx ************************************************');
    console.log(request);
    console.log(request.body);
    console.log(request.body.color);
    console.log(request.body.arraystr);
    console.log(request.body.year); // console.log(body);

    console.log('VVVVVyyyyyyyyyyyyyyyyy end ************************************************');
    let resp = {};

    try {
      console.log(request);
      let index_name = request.params.id;
      index_name = 'license,app-settings';
      console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.search({
        index: index_name,
        body: {
          query: {
            "match_all": {}
          },
          size: 100
        }
      });
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/indices',
    validate: false // validate: {
    //   params: schema.object({
    //     id: schema.string(),
    //     // name: schema.string(),
    //   }),
    // },

  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.cat.indices();
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/plugins',
    validate: false // validate: {
    //   params: schema.object({
    //     id: schema.string(),
    //     // name: schema.string(),
    //   }),
    // },

  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************'); // const { id } = request.params;
    // const params = { emailGroupId: id };
    // console.log(id);

    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      resp = await context.core.opensearch.client.asCurrentUser.cat.plugins();
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/create_index/{indexName}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        indexName: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************');
    const {
      indexName
    } = request.params; // const params = { emailGroupId: id };

    console.log(indexName);
    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      // resp = await (await context.core.opensearch.client.asCurrentUser.indices.getMapping({ index: "license" }) ).body;
      // const index = 'mapping_index_4';
      const index = indexName;
      resp = await context.core.opensearch.client.asCurrentUser.indices.create({
        index: index,
        body: {
          mappings: {
            properties: {
              name: {
                type: 'keyword'
              },
              full_name: {
                type: 'text'
              }
            }
          }
        }
      });
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/delete_index/{indexName}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        indexName: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************');
    const {
      indexName
    } = request.params; // const params = { emailGroupId: id };

    console.log(indexName);
    let resp = {};

    try {
      // console.log(request);
      // let text = request.url.pathname;
      // const myArray = text.split("/");
      // let index_name = myArray[5];
      // let index_name = request.params.id;
      // console.log(index_name);
      // resp = await context.core.opensearch.client.asCurrentUser.cat.plugins();
      // resp = await (await context.core.opensearch.client.asCurrentUser.indices.getMapping({ index: "license" }) ).body;
      // const index = 'mapping_index_4';
      const index = indexName;
      resp = await context.core.opensearch.client.asCurrentUser.indices.delete({
        index: index
      });
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  }); // router.get(
  //   {
  //     path: '/api/elast_alert_plugin/as_current_user/insert_index/{indexName}',
  //     // validate: false,
  //     validate: {
  //       params: schema.object({
  //         indexName: schema.string(),
  //         // name: schema.string(),
  //       }),
  //     },
  //   },
  //   async (context, request, response) => {
  //     console.log('hooooooooooooooooooo ************************************************');
  //     console.log(request);
  //     console.log('hooooooooooooooooooo end ************************************************');
  //     const { indexName } = request.params;
  //     // const params = { emailGroupId: id };
  //     console.log(indexName);
  //     let resp = {}
  //     try {
  //       const index = indexName;
  //       const body = {
  //         mappings: {
  //           properties: {
  //             field1: { type: 'text' },
  //           },
  //         },
  //       };
  //       const results = await context.core.opensearch.client.asCurrentUser.indices.create({
  //         index: 'harshit3',
  //         body,
  //       });
  //       console.log(resp);
  //     } catch (errResp) {
  //       resp = errResp
  //     }
  //     return response.ok({ body: resp });
  //   }
  // );

  router.get({
    path: '/api/elast_alert_plugin/as_current_user/insert_data_index/{indexName}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        indexName: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************');
    const {
      indexName
    } = request.params; // const params = { emailGroupId: id };

    console.log(indexName);
    let resp = {};

    try {
      const index = indexName;
      const body = {
        mappings: {
          properties: {
            field1: {
              type: 'text'
            }
          }
        }
      };
      const results = await context.core.opensearch.client.asCurrentUser.create({
        id: 'oooxx',
        index: index,
        body: {
          name: 'dfd',
          full_name: 'dfxxxx',
          last_name: 'dfxxxx'
        }
      });
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
  router.get({
    path: '/api/elast_alert_plugin/as_current_user/delete_data_index/{indexName}',
    // validate: false,
    validate: {
      params: _configSchema.schema.object({
        indexName: _configSchema.schema.string() // name: schema.string(),

      })
    }
  }, async (context, request, response) => {
    console.log('hooooooooooooooooooo ************************************************');
    console.log(request);
    console.log('hooooooooooooooooooo end ************************************************');
    const {
      indexName
    } = request.params; // const params = { emailGroupId: id };

    console.log(indexName);
    let resp = {};

    try {
      const index = indexName;
      const body = {
        mappings: {
          properties: {
            field1: {
              type: 'text'
            }
          }
        }
      };
      const results = await context.core.opensearch.client.asCurrentUser.delete({
        id: 'oooxx',
        index: index
      });
      console.log(resp);
    } catch (errResp) {
      resp = errResp;
    }

    return response.ok({
      body: resp
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImdldCIsInBhdGgiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJvayIsImJvZHkiLCJ0aW1lIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicmVzcCIsImNvcmUiLCJvcGVuc2VhcmNoIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsInNlYXJjaCIsImluZGV4IiwicXVlcnkiLCJzaXplIiwiZXJyUmVzcCIsImFzSW50ZXJuYWxVc2VyIiwicG9zdCIsImNvbnNvbGUiLCJsb2ciLCJzZWN1cml0eSIsImdldFVzZXIiLCJpZCIsInBhcmFtcyIsImVtYWlsR3JvdXBJZCIsInVybCIsImF2YyIsImZvcm1hdCIsImVudHJ5Iiwic2NoZW1hIiwib2JqZWN0Iiwic3RyaW5nIiwiaW5kZXhfbmFtZSIsImFueSIsImFycmF5T2ZJbmRpY2VzIiwiYXNBcnJheSIsImNvbG9yIiwiYXJyYXlzdHIiLCJ5ZWFyIiwiY2F0IiwiaW5kaWNlcyIsInBsdWdpbnMiLCJpbmRleE5hbWUiLCJjcmVhdGUiLCJtYXBwaW5ncyIsInByb3BlcnRpZXMiLCJuYW1lIiwidHlwZSIsImZ1bGxfbmFtZSIsImRlbGV0ZSIsImZpZWxkMSIsInJlc3VsdHMiLCJsYXN0X25hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFDQTs7QUFDTyxTQUFTQSxZQUFULENBQXNCQyxNQUF0QixFQUF1QztBQUM1Q0EsRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLGlDQURSO0FBRUVDLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsV0FBT0EsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFDakJDLE1BQUFBLElBQUksRUFBRTtBQUNKQyxRQUFBQSxJQUFJLEVBQUUsSUFBSUMsSUFBSixHQUFXQyxXQUFYO0FBREY7QUFEVyxLQUFaLENBQVA7QUFLRCxHQVhIO0FBYUFYLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxxQ0FEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBT0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFFBQUlNLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkNDLE1BQTdDLENBQW9EO0FBQy9EQyxRQUFBQSxLQUFLLEVBQUUsY0FEd0Q7QUFFL0RWLFFBQUFBLElBQUksRUFBRTtBQUNKVyxVQUFBQSxLQUFLLEVBQUU7QUFDTCx5QkFBYTtBQURSLFdBREg7QUFJSkMsVUFBQUEsSUFBSSxFQUFFO0FBSkY7QUFGeUQsT0FBcEQsQ0FBYjtBQVNELEtBVkQsQ0FVRSxPQUFPQyxPQUFQLEVBQWdCO0FBQ2hCVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFDRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0F2Qkg7QUF5QkFaLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxzQ0FEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBRXBDLFFBQUlNLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsSUFBSSxHQUFHLE1BQU1SLE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQk8sY0FBL0IsQ0FBOENMLE1BQTlDLENBQXFEO0FBQ2hFQyxRQUFBQSxLQUFLLEVBQUUsY0FEeUQ7QUFFaEVWLFFBQUFBLElBQUksRUFBRTtBQUNKVyxVQUFBQSxLQUFLLEVBQUU7QUFDTCx5QkFBYTtBQURSLFdBREg7QUFJSkMsVUFBQUEsSUFBSSxFQUFFO0FBSkY7QUFGMEQsT0FBckQsQ0FBYjtBQVNELEtBVkQsQ0FVRSxPQUFPQyxPQUFQLEVBQWdCO0FBQ2hCVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFDRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0F0Qkg7QUF3QkFaLEVBQUFBLE1BQU0sQ0FBQ3VCLElBQVAsQ0FDRTtBQUNFckIsSUFBQUEsSUFBSSxFQUFFLDhCQURSO0FBRUVDLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFPRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsUUFBSU0sSUFBSSxHQUFHLEVBQVg7O0FBQ0EsUUFBSTtBQUNGWSxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaLEVBREUsQ0FHRjtBQUNBOztBQUVBYixNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2Q1UsUUFBN0MsQ0FBc0RDLE9BQXRELEVBQWI7QUFDQUgsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVliLElBQVo7QUFHRCxLQVZELENBVUUsT0FBT1MsT0FBUCxFQUFnQjtBQUNoQkcsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUosT0FBWjtBQUNBVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFFRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0ExQkg7QUE2QkFaLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxtQ0FEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBT0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFFBQUlNLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUVBYixNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXJDLENBSEUsQ0FJRjtBQUVBO0FBQ0E7QUFHRCxLQVZELENBVUUsT0FBT00sT0FBUCxFQUFnQjtBQUNoQkcsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUosT0FBWjtBQUNBVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFFRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0ExQkg7QUE4QkFaLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSw4QkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU07QUFBRXNCLE1BQUFBO0FBQUYsUUFBU3ZCLE9BQU8sQ0FBQ3dCLE1BQXZCO0FBQ0EsVUFBTUEsTUFBTSxHQUFHO0FBQUVDLE1BQUFBLFlBQVksRUFBRUY7QUFBaEIsS0FBZjtBQUNBSixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQU8sQ0FBQzBCLEdBQVIsQ0FBWVosS0FBWixDQUFrQmEsR0FBOUI7QUFDQVIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMEJBQVo7QUFDQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlJLE1BQVosRUFMb0MsQ0FNcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUlJLE1BQU0sR0FBRyxNQUFiO0FBQ0EsV0FBTzNCLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQ2pCQyxNQUFBQSxJQUFJLEVBQUU7QUFDSjBCLFFBQUFBLEtBQUssRUFBRUQ7QUFESDtBQURXLEtBQVosQ0FBUDtBQUtELEdBdkJILEVBMUg0QyxDQXFKNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUFqQyxFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsMERBRFI7QUFFRTtBQUNBQyxJQUFBQSxRQUFRLEVBQUU7QUFDUjBCLE1BQUFBLE1BQU0sRUFBRU0scUJBQU9DLE1BQVAsQ0FBYztBQUNwQlIsUUFBQUEsRUFBRSxFQUFFTyxxQkFBT0UsTUFBUCxFQURnQixDQUVwQjs7QUFGb0IsT0FBZDtBQURBO0FBSFosR0FERixFQWFFLE9BQU9qQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcENrQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx1RUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQU8sQ0FBQ3dCLE1BQVIsQ0FBZUQsRUFBM0I7QUFDQUosSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMkVBQVosRUFIb0MsQ0FJcEM7QUFDQTtBQUNBOztBQUNBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaLEVBREUsQ0FFRjtBQUNBO0FBQ0E7O0FBRUEsVUFBSWlDLFVBQVUsR0FBR2pDLE9BQU8sQ0FBQ3dCLE1BQVIsQ0FBZUQsRUFBaEM7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlhLFVBQVo7QUFDQTFCLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDQyxNQUE3QyxDQUFvRDtBQUMvREMsUUFBQUEsS0FBSyxFQUFFb0IsVUFEd0Q7QUFFL0Q5QixRQUFBQSxJQUFJLEVBQUU7QUFDSlcsVUFBQUEsS0FBSyxFQUFFO0FBQ0wseUJBQWE7QUFEUixXQURIO0FBSUpDLFVBQUFBLElBQUksRUFBRTtBQUpGO0FBRnlELE9BQXBELENBQWI7QUFTRCxLQWpCRCxDQWlCRSxPQUFPQyxPQUFQLEVBQWdCO0FBQ2hCVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFDRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0ExQ0g7QUFnREFaLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxnRUFEUjtBQUVFO0FBQ0FDLElBQUFBLFFBQVEsRUFBRTtBQUNSMEIsTUFBQUEsTUFBTSxFQUFFTSxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCUixRQUFBQSxFQUFFLEVBQUVPLHFCQUFPRSxNQUFQLEVBRGdCLENBRXBCOztBQUZvQixPQUFkO0FBREE7QUFIWixHQURGLEVBYUUsT0FBT2pDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQ2tCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHlFQUFaO0FBQ0FELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBTyxDQUFDd0IsTUFBUixDQUFlRCxFQUEzQjtBQUNBSixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3RUFBWjtBQUVBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaO0FBQ0EsVUFBSWlDLFVBQVUsR0FBR2pDLE9BQU8sQ0FBQ3dCLE1BQVIsQ0FBZUQsRUFBaEM7QUFDQVUsTUFBQUEsVUFBVSxHQUFDLHNCQUFYO0FBQ0FkLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYSxVQUFaO0FBQ0ExQixNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2Q0MsTUFBN0MsQ0FBb0Q7QUFDL0RDLFFBQUFBLEtBQUssRUFBRW9CLFVBRHdEO0FBRS9EOUIsUUFBQUEsSUFBSSxFQUFFO0FBQ0pXLFVBQUFBLEtBQUssRUFBRTtBQUNMLHlCQUFhO0FBRFIsV0FESDtBQUlKQyxVQUFBQSxJQUFJLEVBQUU7QUFKRjtBQUZ5RCxPQUFwRCxDQUFiO0FBU0QsS0FkRCxDQWNFLE9BQU9DLE9BQVAsRUFBZ0I7QUFDaEJULE1BQUFBLElBQUksR0FBR1MsT0FBUDtBQUNEOztBQUNELFdBQU9mLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQUVDLE1BQUFBLElBQUksRUFBRUk7QUFBUixLQUFaLENBQVA7QUFDRCxHQXJDSDtBQTBDQVosRUFBQUEsTUFBTSxDQUFDdUIsSUFBUCxDQUNFO0FBQ0VyQixJQUFBQSxJQUFJLEVBQUUsNERBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1JLLE1BQUFBLElBQUksRUFBRTJCLHFCQUFPSSxHQUFQO0FBREU7QUFGWixHQURGLEVBU0UsT0FBT25DLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQ2tCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHlFQUFaO0FBQ0EsVUFBTWUsY0FBYyxHQUFDbkMsT0FBTyxDQUFDRyxJQUFSLENBQWFpQyxPQUFsQztBQUNBakIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVllLGNBQVosRUFIb0MsQ0FJcEM7O0FBQ0FoQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3RUFBWjtBQUVBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaLEVBREUsQ0FFRjtBQUNBO0FBQ0E7O0FBQ0FPLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDQyxNQUE3QyxDQUFvRDtBQUMvREMsUUFBQUEsS0FBSyxFQUFFc0IsY0FEd0Q7QUFFL0RoQyxRQUFBQSxJQUFJLEVBQUU7QUFDSlcsVUFBQUEsS0FBSyxFQUFFO0FBQ0wseUJBQWE7QUFEUixXQURIO0FBSUpDLFVBQUFBLElBQUksRUFBRTtBQUpGO0FBRnlELE9BQXBELENBQWI7QUFTRCxLQWRELENBY0UsT0FBT0MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBbkNIO0FBdUNBWixFQUFBQSxNQUFNLENBQUN1QixJQUFQLENBQ0U7QUFDRXJCLElBQUFBLElBQUksRUFBRSxzREFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFDUkssTUFBQUEsSUFBSSxFQUFFMkIscUJBQU9JLEdBQVA7QUFERTtBQUZaLEdBREYsRUFPRSxPQUFPbkMsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDa0IsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksOEVBQVo7QUFDQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaO0FBQ0FtQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQU8sQ0FBQ0csSUFBcEI7QUFDQWdCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBTyxDQUFDRyxJQUFSLENBQWFrQyxLQUF6QjtBQUNBbEIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFPLENBQUNHLElBQVIsQ0FBYW1DLFFBQXpCO0FBQ0FuQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQU8sQ0FBQ0csSUFBUixDQUFhb0MsSUFBekIsRUFOb0MsQ0FPcEM7O0FBQ0FwQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw2RUFBWjtBQUVBLFFBQUliLElBQUksR0FBRyxFQUFYOztBQUNBLFFBQUk7QUFDRlksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaO0FBQ0EsVUFBSWlDLFVBQVUsR0FBR2pDLE9BQU8sQ0FBQ3dCLE1BQVIsQ0FBZUQsRUFBaEM7QUFDQVUsTUFBQUEsVUFBVSxHQUFDLHNCQUFYO0FBQ0FkLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYSxVQUFaO0FBQ0ExQixNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2Q0MsTUFBN0MsQ0FBb0Q7QUFDL0RDLFFBQUFBLEtBQUssRUFBRW9CLFVBRHdEO0FBRS9EOUIsUUFBQUEsSUFBSSxFQUFFO0FBQ0pXLFVBQUFBLEtBQUssRUFBRTtBQUNMLHlCQUFhO0FBRFIsV0FESDtBQUlKQyxVQUFBQSxJQUFJLEVBQUU7QUFKRjtBQUZ5RCxPQUFwRCxDQUFiO0FBU0QsS0FkRCxDQWNFLE9BQU9DLE9BQVAsRUFBZ0I7QUFDaEJULE1BQUFBLElBQUksR0FBR1MsT0FBUDtBQUNEOztBQUNELFdBQU9mLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQUVDLE1BQUFBLElBQUksRUFBRUk7QUFBUixLQUFaLENBQVA7QUFDRCxHQXBDSDtBQTRDQVosRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLGlEQURSO0FBRUVDLElBQUFBLFFBQVEsRUFBRSxLQUZaLENBR0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVJGLEdBREYsRUFhRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcENrQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx1RUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQVo7QUFDQW1CLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJFQUFaLEVBSG9DLENBSXBDO0FBQ0E7QUFDQTs7QUFDQSxRQUFJYixJQUFJLEdBQUcsRUFBWDs7QUFJQSxRQUFJO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0FBLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDNkIsR0FBN0MsQ0FBaURDLE9BQWpELEVBQWI7QUFDQXRCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYixJQUFaO0FBQ0QsS0FWRCxDQVVFLE9BQU9TLE9BQVAsRUFBZ0I7QUFDaEJULE1BQUFBLElBQUksR0FBR1MsT0FBUDtBQUNEOztBQUNELFdBQU9mLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQUVDLE1BQUFBLElBQUksRUFBRUk7QUFBUixLQUFaLENBQVA7QUFDRCxHQXRDSDtBQXlDQVosRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLGlEQURSO0FBRUVDLElBQUFBLFFBQVEsRUFBRSxLQUZaLENBR0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVJGLEdBREYsRUFhRSxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcENrQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx1RUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQVo7QUFDQW1CLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJFQUFaLEVBSG9DLENBSXBDO0FBQ0E7QUFDQTs7QUFDQSxRQUFJYixJQUFJLEdBQUcsRUFBWDs7QUFJQSxRQUFJO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0FBLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDNkIsR0FBN0MsQ0FBaURFLE9BQWpELEVBQWI7QUFFQXZCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYixJQUFaO0FBQ0QsS0FYRCxDQVdFLE9BQU9TLE9BQVAsRUFBZ0I7QUFDaEJULE1BQUFBLElBQUksR0FBR1MsT0FBUDtBQUNEOztBQUNELFdBQU9mLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQUVDLE1BQUFBLElBQUksRUFBRUk7QUFBUixLQUFaLENBQVA7QUFDRCxHQXZDSDtBQTBDQVosRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLGtFQURSO0FBRUU7QUFDQUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1IwQixNQUFBQSxNQUFNLEVBQUVNLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJZLFFBQUFBLFNBQVMsRUFBRWIscUJBQU9FLE1BQVAsRUFEUyxDQUVwQjs7QUFGb0IsT0FBZDtBQURBO0FBSFosR0FERixFQWFFLE9BQU9qQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcENrQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx1RUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQVo7QUFDQW1CLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJFQUFaO0FBQ0EsVUFBTTtBQUFFdUIsTUFBQUE7QUFBRixRQUFnQjNDLE9BQU8sQ0FBQ3dCLE1BQTlCLENBSm9DLENBS3BDOztBQUNBTCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXVCLFNBQVo7QUFDQSxRQUFJcEMsSUFBSSxHQUFHLEVBQVg7O0FBSUEsUUFBSTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBRUE7QUFDQSxZQUFNTSxLQUFLLEdBQUc4QixTQUFkO0FBQ0FwQyxNQUFBQSxJQUFJLEdBQUcsTUFBTVIsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2QzhCLE9BQTdDLENBQXFERyxNQUFyRCxDQUE0RDtBQUN2RS9CLFFBQUFBLEtBQUssRUFBRUEsS0FEZ0U7QUFDekRWLFFBQUFBLElBQUksRUFBRTtBQUNsQjBDLFVBQUFBLFFBQVEsRUFBRTtBQUFFQyxZQUFBQSxVQUFVLEVBQUU7QUFBRUMsY0FBQUEsSUFBSSxFQUFFO0FBQUVDLGdCQUFBQSxJQUFJLEVBQUU7QUFBUixlQUFSO0FBQTZCQyxjQUFBQSxTQUFTLEVBQUU7QUFBRUQsZ0JBQUFBLElBQUksRUFBRTtBQUFSO0FBQXhDO0FBQWQ7QUFEUTtBQURtRCxPQUE1RCxDQUFiO0FBS0E3QixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWIsSUFBWjtBQUNELEtBbEJELENBa0JFLE9BQU9TLE9BQVAsRUFBZ0I7QUFDaEJULE1BQUFBLElBQUksR0FBR1MsT0FBUDtBQUNEOztBQUNELFdBQU9mLFFBQVEsQ0FBQ0MsRUFBVCxDQUFZO0FBQUVDLE1BQUFBLElBQUksRUFBRUk7QUFBUixLQUFaLENBQVA7QUFDRCxHQTlDSDtBQWtEQVosRUFBQUEsTUFBTSxDQUFDQyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFFLGtFQURSO0FBRUU7QUFDQUMsSUFBQUEsUUFBUSxFQUFFO0FBQ1IwQixNQUFBQSxNQUFNLEVBQUVNLHFCQUFPQyxNQUFQLENBQWM7QUFDcEJZLFFBQUFBLFNBQVMsRUFBRWIscUJBQU9FLE1BQVAsRUFEUyxDQUVwQjs7QUFGb0IsT0FBZDtBQURBO0FBSFosR0FERixFQWFFLE9BQU9qQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcENrQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx1RUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXBCLE9BQVo7QUFDQW1CLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJFQUFaO0FBQ0EsVUFBTTtBQUFFdUIsTUFBQUE7QUFBRixRQUFnQjNDLE9BQU8sQ0FBQ3dCLE1BQTlCLENBSm9DLENBS3BDOztBQUNBTCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXVCLFNBQVo7QUFDQSxRQUFJcEMsSUFBSSxHQUFHLEVBQVg7O0FBSUEsUUFBSTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBLFlBQU1NLEtBQUssR0FBRzhCLFNBQWQ7QUFDQXBDLE1BQUFBLElBQUksR0FBRyxNQUFNUixPQUFPLENBQUNTLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGFBQS9CLENBQTZDOEIsT0FBN0MsQ0FBcURTLE1BQXJELENBQTREO0FBQUVyQyxRQUFBQSxLQUFLLEVBQUVBO0FBQVQsT0FBNUQsQ0FBYjtBQUNBTSxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWIsSUFBWjtBQUNELEtBZkQsQ0FlRSxPQUFPUyxPQUFQLEVBQWdCO0FBQ2hCVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFDRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0EzQ0gsRUE5ZTRDLENBNmhCNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUVBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBWixFQUFBQSxNQUFNLENBQUNDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsdUVBRFI7QUFFRTtBQUNBQyxJQUFBQSxRQUFRLEVBQUU7QUFDUjBCLE1BQUFBLE1BQU0sRUFBRU0scUJBQU9DLE1BQVAsQ0FBYztBQUNwQlksUUFBQUEsU0FBUyxFQUFFYixxQkFBT0UsTUFBUCxFQURTLENBRXBCOztBQUZvQixPQUFkO0FBREE7QUFIWixHQURGLEVBYUUsT0FBT2pDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQ2tCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVFQUFaO0FBQ0FELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZcEIsT0FBWjtBQUNBbUIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMkVBQVo7QUFDQSxVQUFNO0FBQUV1QixNQUFBQTtBQUFGLFFBQWdCM0MsT0FBTyxDQUFDd0IsTUFBOUIsQ0FKb0MsQ0FLcEM7O0FBQ0FMLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZdUIsU0FBWjtBQUNBLFFBQUlwQyxJQUFJLEdBQUcsRUFBWDs7QUFJQSxRQUFJO0FBRUYsWUFBTU0sS0FBSyxHQUFHOEIsU0FBZDtBQUdBLFlBQU14QyxJQUFJLEdBQUc7QUFDWDBDLFFBQUFBLFFBQVEsRUFBRTtBQUNSQyxVQUFBQSxVQUFVLEVBQUU7QUFDVkssWUFBQUEsTUFBTSxFQUFFO0FBQUVILGNBQUFBLElBQUksRUFBRTtBQUFSO0FBREU7QUFESjtBQURDLE9BQWI7QUFRQSxZQUFNSSxPQUFPLEdBQUcsTUFBTXJELE9BQU8sQ0FBQ1MsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsYUFBL0IsQ0FBNkNpQyxNQUE3QyxDQUFvRDtBQUN4RXJCLFFBQUFBLEVBQUUsRUFBRSxPQURvRTtBQUV4RVYsUUFBQUEsS0FBSyxFQUFFQSxLQUZpRTtBQUd4RVYsUUFBQUEsSUFBSSxFQUFFO0FBQ0o0QyxVQUFBQSxJQUFJLEVBQUUsS0FERjtBQUVKRSxVQUFBQSxTQUFTLEVBQUUsUUFGUDtBQUdKSSxVQUFBQSxTQUFTLEVBQUU7QUFIUDtBQUhrRSxPQUFwRCxDQUF0QjtBQVdBbEMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVliLElBQVo7QUFDRCxLQXpCRCxDQXlCRSxPQUFPUyxPQUFQLEVBQWdCO0FBQ2hCVCxNQUFBQSxJQUFJLEdBQUdTLE9BQVA7QUFDRDs7QUFDRCxXQUFPZixRQUFRLENBQUNDLEVBQVQsQ0FBWTtBQUFFQyxNQUFBQSxJQUFJLEVBQUVJO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0FyREg7QUF5REFaLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSx1RUFEUjtBQUVFO0FBQ0FDLElBQUFBLFFBQVEsRUFBRTtBQUNSMEIsTUFBQUEsTUFBTSxFQUFFTSxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCWSxRQUFBQSxTQUFTLEVBQUViLHFCQUFPRSxNQUFQLEVBRFMsQ0FFcEI7O0FBRm9CLE9BQWQ7QUFEQTtBQUhaLEdBREYsRUFhRSxPQUFPakMsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDa0IsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksdUVBQVo7QUFDQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlwQixPQUFaO0FBQ0FtQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSwyRUFBWjtBQUNBLFVBQU07QUFBRXVCLE1BQUFBO0FBQUYsUUFBZ0IzQyxPQUFPLENBQUN3QixNQUE5QixDQUpvQyxDQUtwQzs7QUFDQUwsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVl1QixTQUFaO0FBQ0EsUUFBSXBDLElBQUksR0FBRyxFQUFYOztBQUlBLFFBQUk7QUFFRixZQUFNTSxLQUFLLEdBQUc4QixTQUFkO0FBR0EsWUFBTXhDLElBQUksR0FBRztBQUNYMEMsUUFBQUEsUUFBUSxFQUFFO0FBQ1JDLFVBQUFBLFVBQVUsRUFBRTtBQUNWSyxZQUFBQSxNQUFNLEVBQUU7QUFBRUgsY0FBQUEsSUFBSSxFQUFFO0FBQVI7QUFERTtBQURKO0FBREMsT0FBYjtBQVFBLFlBQU1JLE9BQU8sR0FBRyxNQUFNckQsT0FBTyxDQUFDUyxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxhQUEvQixDQUE2Q3VDLE1BQTdDLENBQW9EO0FBQ3hFM0IsUUFBQUEsRUFBRSxFQUFFLE9BRG9FO0FBRXhFVixRQUFBQSxLQUFLLEVBQUVBO0FBRmlFLE9BQXBELENBQXRCO0FBTUFNLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYixJQUFaO0FBQ0QsS0FwQkQsQ0FvQkUsT0FBT1MsT0FBUCxFQUFnQjtBQUNoQlQsTUFBQUEsSUFBSSxHQUFHUyxPQUFQO0FBQ0Q7O0FBQ0QsV0FBT2YsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFSTtBQUFSLEtBQVosQ0FBUDtBQUNELEdBaERIO0FBbUREIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vZXhhbXBsZScsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICB0aW1lOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2N1cnJlbnR1c2VyJyxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuXG5cbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiAnYXBwLXNldHRpbmdzJyxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBcIm1hdGNoX2FsbFwiOiB7fVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNpemU6IDEwMFxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgcmVzcCA9IGVyclJlc3BcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9pbnRlcm5hbHVzZXInLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG5cbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogJ2FwcC1zZXR0aW5ncycsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2NhdHMnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG5cblxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgbGV0IHJlc3AgPSB7fVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc29sZS5sb2coJ2FhJyk7XG5cbiAgICAgICAgLy8gcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmNhdC5pbmRpY2VzKCk7XG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWN1cml0eS5nZXRSb2xlKCk7XG5cbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlY3VyaXR5LmdldFVzZXIoKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG5cblxuICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAgICAgICBjb25zb2xlLmxvZygnYmInKTtcbiAgICAgICAgY29uc29sZS5sb2coZXJyUmVzcCk7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG5cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL3Rlc3RfdXNlcicsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBsZXQgcmVzcCA9IHt9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zb2xlLmxvZygnYWEnKTtcblxuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50O1xuICAgICAgICAvLyAvLyByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuc2VjdXJpdHkuZ2V0Um9sZSgpO1xuXG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWN1cml0eS5nZXRVc2VyKCk7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3ApO1xuXG5cbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgY29uc29sZS5sb2coJ2JiJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGVyclJlc3ApO1xuICAgICAgICByZXNwID0gZXJyUmVzcFxuXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL3BhdGgnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCB7IGlkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAgICAgY29uc29sZS5sb2cocmVxdWVzdC51cmwucXVlcnkuYXZjKTtcbiAgICAgIGNvbnNvbGUubG9nKCdmZGZkeHh4eHh4eHh4eHh4eHh4eHh4eHgnKTtcbiAgICAgIGNvbnNvbGUubG9nKHBhcmFtcyk7XG4gICAgICAvLyBjb25zdCB7IGRldGVjdG9ySWQgfSA9IHJlcXVlc3QucGFyYW1zO1xuICAgICAgLy8gY29uc3QgeyBkZXRlY3RvcklkIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBkZXRlY3RvcklkIH07XG4gICAgICAvLyBjb25zdCBmb3JtYXQgPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIHZhciBmb3JtYXQgPSBwYXJhbXM7XG4gICAgICAvLyAgdHlwZSA9IHJlcXVlc3QucGFyYW1zLnR5cGU7XG4gICAgICB2YXIgZm9ybWF0ID0gJ2NkZGQnO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIGVudHJ5OiBmb3JtYXRcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIC8vICAgcm91dGVyLmdldChcbiAgLy8gICAgIHtcbiAgLy8gICAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2FzX2N1cnJlbnRfdXNlci9jaGVja19pbmRleCcsXG4gIC8vICAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgLy8gICAgIH0sXG5cblxuICAvLyAgICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gIC8vICAgICAgIGxldCByZXNwID0ge31cbiAgLy8gICAgICAgdHJ5IHtcbiAgLy8gICAgICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyhhYmMpOyBcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXF1ZXN0LnVybC5xdWVyeS5pbmRleF9uYW1lKTtcbiAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZygnZmRmZHh4eHh4eHh4eHh4eHh4eHh4eHh4Jyk7XG4gIC8vICAgICAgICAgLy8gbGV0IGluZGV4TmFtZSA9IHJlcXVlc3QudXJsLnF1ZXJ5LmluZGV4X25hbWU7XG4gIC8vICAgICAgICAgLy8gaW5kZXhOYW1lPSdhcHAtc2V0dGluZ3MnO1xuICAvLyAgICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QudXJsLnNlYXJjaCk7IFxuICAvLyAgICAgICAgIGxldCB0ZXh0ID0gcmVxdWVzdC51cmwuc2VhcmNoO1xuICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIj1cIik7XG4gIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVsxXTtcbiAgLy8gY29uc29sZS5sb2coaW5kZXhfbmFtZSk7IFxuICAvLyAgICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xuICAvLyAgICAgICAgICAgaW5kZXg6IGluZGV4X25hbWUsXG4gIC8vICAgICAgICAgICBib2R5OiB7XG4gIC8vICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gIC8vICAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgLy8gICAgICAgICAgICAgfSxcbiAgLy8gICAgICAgICAgICAgc2l6ZTogMTAwXG4gIC8vICAgICAgICAgICB9XG4gIC8vICAgICAgICAgfSlcbiAgLy8gICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAvLyAgICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gIC8vICAgICAgIH1cbiAgLy8gICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzcCB9KTtcbiAgLy8gICAgIH1cbiAgLy8gICApO1xuXG5cblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvY2hlY2tfaW5kZXgve2lkfScsXG4gICAgICAvLyB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0LnBhcmFtcy5pZCk7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gZW5kICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgLy8gY29uc3QgeyBpZCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGlkKTtcbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICAvLyBsZXQgdGV4dCA9IHJlcXVlc3QudXJsLnBhdGhuYW1lO1xuICAgICAgICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIi9cIik7XG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVs1XTtcblxuICAgICAgICBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICBjb25zb2xlLmxvZyhpbmRleF9uYW1lKTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IGluZGV4X25hbWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG5cblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvY2hlY2tfaW5kZXhfYXJyYXkve2lkfScsXG4gICAgICAvLyB2YWxpZGF0ZTogZmFsc2UsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygneHh4eHh4eHh4eHh4eHh4eHh4eHh4eCAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKionKTtcbiAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QucGFyYW1zLmlkKTtcbiAgICAgIGNvbnNvbGUubG9nKCd5eXl5eXl5eXl5eXl5eXl5eSBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG5cbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICBpbmRleF9uYW1lPSdsaWNlbnNlLGFwcC1zZXR0aW5ncyc7XG4gICAgICAgIGNvbnNvbGUubG9nKGluZGV4X25hbWUpO1xuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogaW5kZXhfbmFtZSxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICBcIm1hdGNoX2FsbFwiOiB7fVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNpemU6IDEwMFxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgcmVzcCA9IGVyclJlc3BcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuXG5cblxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vYXNfY3VycmVudF91c2VyL2NoZWNrX2luZGV4X29iamVjdCcsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXG4gICAgICB9LFxuICAgIH0sXG5cblxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ3h4eHh4eHh4eHh4eHh4eHh4eHh4eHggKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zdCBhcnJheU9mSW5kaWNlcz1yZXF1ZXN0LmJvZHkuYXNBcnJheTtcbiAgICAgIGNvbnNvbGUubG9nKGFycmF5T2ZJbmRpY2VzKTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGFycmF5T2ZJbmRpY2VzWzFdKTtcbiAgICAgIGNvbnNvbGUubG9nKCd5eXl5eXl5eXl5eXl5eXl5eSBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG5cbiAgICAgIGxldCByZXNwID0ge31cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICAvLyBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICAvLyBpbmRleF9uYW1lPSdsaWNlbnNlLGFwcC1zZXR0aW5ncyc7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGluZGV4X25hbWUpO1xuICAgICAgICByZXNwID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuc2VhcmNoKHtcbiAgICAgICAgICBpbmRleDogYXJyYXlPZkluZGljZXMsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvY2hlY2tfb2JqZWN0JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdWVlZWVnh4eHh4eHh4eHh4eHh4eHh4eHh4eHggKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QuYm9keSk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0LmJvZHkuY29sb3IpO1xuICAgICAgY29uc29sZS5sb2cocmVxdWVzdC5ib2R5LmFycmF5c3RyKTtcbiAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QuYm9keS55ZWFyKTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGJvZHkpO1xuICAgICAgY29uc29sZS5sb2coJ1ZWVlZWeXl5eXl5eXl5eXl5eXl5eXkgZW5kICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuXG4gICAgICBsZXQgcmVzcCA9IHt9XG4gICAgICB0cnkge1xuICAgICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgICAgbGV0IGluZGV4X25hbWUgPSByZXF1ZXN0LnBhcmFtcy5pZDtcbiAgICAgICAgaW5kZXhfbmFtZT0nbGljZW5zZSxhcHAtc2V0dGluZ3MnO1xuICAgICAgICBjb25zb2xlLmxvZyhpbmRleF9uYW1lKTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaCh7XG4gICAgICAgICAgaW5kZXg6IGluZGV4X25hbWUsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgXCJtYXRjaF9hbGxcIjoge31cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzaXplOiAxMDBcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG5cblxuXG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vYXNfY3VycmVudF91c2VyL2luZGljZXMnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgICAgLy8gdmFsaWRhdGU6IHtcbiAgICAgIC8vICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgIC8vICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgLy8gICAgIC8vIG5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgIC8vICAgfSksXG4gICAgICAvLyB9LFxuICAgIH0sXG5cblxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ2hvb29vb29vb29vb29vb29vb29vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgY29uc29sZS5sb2cocmVxdWVzdCk7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gZW5kICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgLy8gY29uc3QgeyBpZCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGlkKTtcbiAgICAgIGxldCByZXNwID0ge31cblxuXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICAvLyBsZXQgdGV4dCA9IHJlcXVlc3QudXJsLnBhdGhuYW1lO1xuICAgICAgICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIi9cIik7XG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVs1XTtcblxuICAgICAgICAvLyBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhpbmRleF9uYW1lKTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmNhdC5pbmRpY2VzKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3ApO1xuICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAgICAgICByZXNwID0gZXJyUmVzcFxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzcCB9KTtcbiAgICB9XG4gICk7XG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vYXNfY3VycmVudF91c2VyL3BsdWdpbnMnLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgICAgLy8gdmFsaWRhdGU6IHtcbiAgICAgIC8vICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgIC8vICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgLy8gICAgIC8vIG5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgIC8vICAgfSksXG4gICAgICAvLyB9LFxuICAgIH0sXG5cblxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ2hvb29vb29vb29vb29vb29vb29vICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgY29uc29sZS5sb2cocmVxdWVzdCk7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gZW5kICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKicpO1xuICAgICAgLy8gY29uc3QgeyBpZCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIC8vIGNvbnNvbGUubG9nKGlkKTtcbiAgICAgIGxldCByZXNwID0ge31cblxuXG5cbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgICAvLyBsZXQgdGV4dCA9IHJlcXVlc3QudXJsLnBhdGhuYW1lO1xuICAgICAgICAvLyBjb25zdCBteUFycmF5ID0gdGV4dC5zcGxpdChcIi9cIik7XG4gICAgICAgIC8vIGxldCBpbmRleF9uYW1lID0gbXlBcnJheVs1XTtcblxuICAgICAgICAvLyBsZXQgaW5kZXhfbmFtZSA9IHJlcXVlc3QucGFyYW1zLmlkO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhpbmRleF9uYW1lKTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmNhdC5wbHVnaW5zKCk7XG5cbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvY3JlYXRlX2luZGV4L3tpbmRleE5hbWV9JyxcbiAgICAgIC8vIHZhbGlkYXRlOiBmYWxzZSxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW5kZXhOYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zdCB7IGluZGV4TmFtZSB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIGNvbnNvbGUubG9nKGluZGV4TmFtZSk7XG4gICAgICBsZXQgcmVzcCA9IHt9XG5cblxuXG4gICAgICB0cnkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgICAgLy8gbGV0IHRleHQgPSByZXF1ZXN0LnVybC5wYXRobmFtZTtcbiAgICAgICAgLy8gY29uc3QgbXlBcnJheSA9IHRleHQuc3BsaXQoXCIvXCIpO1xuICAgICAgICAvLyBsZXQgaW5kZXhfbmFtZSA9IG15QXJyYXlbNV07XG5cbiAgICAgICAgLy8gbGV0IGluZGV4X25hbWUgPSByZXF1ZXN0LnBhcmFtcy5pZDtcbiAgICAgICAgLy8gY29uc29sZS5sb2coaW5kZXhfbmFtZSk7XG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCAoYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5nZXRNYXBwaW5nKHsgaW5kZXg6IFwibGljZW5zZVwiIH0pICkuYm9keTtcblxuICAgICAgICAvLyBjb25zdCBpbmRleCA9ICdtYXBwaW5nX2luZGV4XzQnO1xuICAgICAgICBjb25zdCBpbmRleCA9IGluZGV4TmFtZTtcbiAgICAgICAgcmVzcCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuY3JlYXRlKHtcbiAgICAgICAgICBpbmRleDogaW5kZXgsIGJvZHk6IHtcbiAgICAgICAgICAgIG1hcHBpbmdzOiB7IHByb3BlcnRpZXM6IHsgbmFtZTogeyB0eXBlOiAna2V5d29yZCcgfSwgZnVsbF9uYW1lOiB7IHR5cGU6ICd0ZXh0JyB9IH0gfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3ApO1xuICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAgICAgICByZXNwID0gZXJyUmVzcFxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzcCB9KTtcbiAgICB9XG4gICk7XG5cblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvZGVsZXRlX2luZGV4L3tpbmRleE5hbWV9JyxcbiAgICAgIC8vIHZhbGlkYXRlOiBmYWxzZSxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW5kZXhOYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zdCB7IGluZGV4TmFtZSB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIGNvbnNvbGUubG9nKGluZGV4TmFtZSk7XG4gICAgICBsZXQgcmVzcCA9IHt9XG5cblxuXG4gICAgICB0cnkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgICAgLy8gbGV0IHRleHQgPSByZXF1ZXN0LnVybC5wYXRobmFtZTtcbiAgICAgICAgLy8gY29uc3QgbXlBcnJheSA9IHRleHQuc3BsaXQoXCIvXCIpO1xuICAgICAgICAvLyBsZXQgaW5kZXhfbmFtZSA9IG15QXJyYXlbNV07XG5cbiAgICAgICAgLy8gbGV0IGluZGV4X25hbWUgPSByZXF1ZXN0LnBhcmFtcy5pZDtcbiAgICAgICAgLy8gY29uc29sZS5sb2coaW5kZXhfbmFtZSk7XG4gICAgICAgIC8vIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5jYXQucGx1Z2lucygpO1xuICAgICAgICAvLyByZXNwID0gYXdhaXQgKGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZ2V0TWFwcGluZyh7IGluZGV4OiBcImxpY2Vuc2VcIiB9KSApLmJvZHk7XG5cbiAgICAgICAgLy8gY29uc3QgaW5kZXggPSAnbWFwcGluZ19pbmRleF80JztcbiAgICAgICAgY29uc3QgaW5kZXggPSBpbmRleE5hbWU7XG4gICAgICAgIHJlc3AgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmRlbGV0ZSh7IGluZGV4OiBpbmRleCB9KTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcCk7XG4gICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAgIH1cbiAgKTtcblxuXG4gIC8vIHJvdXRlci5nZXQoXG4gIC8vICAge1xuICAvLyAgICAgcGF0aDogJy9hcGkvZWxhc3RfYWxlcnRfcGx1Z2luL2FzX2N1cnJlbnRfdXNlci9pbnNlcnRfaW5kZXgve2luZGV4TmFtZX0nLFxuICAvLyAgICAgLy8gdmFsaWRhdGU6IGZhbHNlLFxuICAvLyAgICAgdmFsaWRhdGU6IHtcbiAgLy8gICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgLy8gICAgICAgICBpbmRleE5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgLy8gICAgICAgICAvLyBuYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gIC8vICAgICAgIH0pLFxuICAvLyAgICAgfSxcbiAgLy8gICB9LFxuXG5cbiAgLy8gICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgLy8gICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKionKTtcbiAgLy8gICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAvLyAgICAgY29uc29sZS5sb2coJ2hvb29vb29vb29vb29vb29vb29vIGVuZCAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKionKTtcbiAgLy8gICAgIGNvbnN0IHsgaW5kZXhOYW1lIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgLy8gICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAvLyAgICAgY29uc29sZS5sb2coaW5kZXhOYW1lKTtcbiAgLy8gICAgIGxldCByZXNwID0ge31cblxuXG5cbiAgLy8gICAgIHRyeSB7XG5cbiAgLy8gICAgICAgY29uc3QgaW5kZXggPSBpbmRleE5hbWU7XG5cblxuICAvLyAgICAgICBjb25zdCBib2R5ID0ge1xuICAvLyAgICAgICAgIG1hcHBpbmdzOiB7XG4gIC8vICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gIC8vICAgICAgICAgICAgIGZpZWxkMTogeyB0eXBlOiAndGV4dCcgfSxcbiAgLy8gICAgICAgICAgIH0sXG4gIC8vICAgICAgICAgfSxcbiAgLy8gICAgICAgfTtcblxuICAvLyAgICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5jcmVhdGUoe1xuICAvLyAgICAgICAgIGluZGV4OiAnaGFyc2hpdDMnLFxuICAvLyAgICAgICAgIGJvZHksXG4gIC8vICAgICAgIH0pO1xuXG5cbiAgLy8gICAgICAgY29uc29sZS5sb2cocmVzcCk7XG4gIC8vICAgICB9IGNhdGNoIChlcnJSZXNwKSB7XG4gIC8vICAgICAgIHJlc3AgPSBlcnJSZXNwXG4gIC8vICAgICB9XG4gIC8vICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXNwIH0pO1xuICAvLyAgIH1cbiAgLy8gKTtcblxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL2VsYXN0X2FsZXJ0X3BsdWdpbi9hc19jdXJyZW50X3VzZXIvaW5zZXJ0X2RhdGFfaW5kZXgve2luZGV4TmFtZX0nLFxuICAgICAgLy8gdmFsaWRhdGU6IGZhbHNlLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpbmRleE5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICAvLyBuYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuXG5cbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKionKTtcbiAgICAgIGNvbnNvbGUubG9nKHJlcXVlc3QpO1xuICAgICAgY29uc29sZS5sb2coJ2hvb29vb29vb29vb29vb29vb29vIGVuZCAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKionKTtcbiAgICAgIGNvbnN0IHsgaW5kZXhOYW1lIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIC8vIGNvbnN0IHBhcmFtcyA9IHsgZW1haWxHcm91cElkOiBpZCB9O1xuICAgICAgY29uc29sZS5sb2coaW5kZXhOYW1lKTtcbiAgICAgIGxldCByZXNwID0ge31cblxuXG5cbiAgICAgIHRyeSB7XG5cbiAgICAgICAgY29uc3QgaW5kZXggPSBpbmRleE5hbWU7XG5cblxuICAgICAgICBjb25zdCBib2R5ID0ge1xuICAgICAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgIGZpZWxkMTogeyB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcblxuICAgICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuY3JlYXRlKHtcbiAgICAgICAgICBpZDogJ29vb3h4JyxcbiAgICAgICAgICBpbmRleDogaW5kZXgsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgbmFtZTogJ2RmZCcsXG4gICAgICAgICAgICBmdWxsX25hbWU6ICdkZnh4eHgnLFxuICAgICAgICAgICAgbGFzdF9uYW1lOiAnZGZ4eHh4J1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cblxuICAgICAgICBjb25zb2xlLmxvZyhyZXNwKTtcbiAgICAgIH0gY2F0Y2ggKGVyclJlc3ApIHtcbiAgICAgICAgcmVzcCA9IGVyclJlc3BcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3AgfSk7XG4gICAgfVxuICApO1xuXG5cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS9lbGFzdF9hbGVydF9wbHVnaW4vYXNfY3VycmVudF91c2VyL2RlbGV0ZV9kYXRhX2luZGV4L3tpbmRleE5hbWV9JyxcbiAgICAgIC8vIHZhbGlkYXRlOiBmYWxzZSxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW5kZXhOYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgLy8gbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcblxuXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZygnaG9vb29vb29vb29vb29vb29vb28gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0KTtcbiAgICAgIGNvbnNvbGUubG9nKCdob29vb29vb29vb29vb29vb29vbyBlbmQgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqJyk7XG4gICAgICBjb25zdCB7IGluZGV4TmFtZSB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBjb25zdCBwYXJhbXMgPSB7IGVtYWlsR3JvdXBJZDogaWQgfTtcbiAgICAgIGNvbnNvbGUubG9nKGluZGV4TmFtZSk7XG4gICAgICBsZXQgcmVzcCA9IHt9XG5cblxuXG4gICAgICB0cnkge1xuXG4gICAgICAgIGNvbnN0IGluZGV4ID0gaW5kZXhOYW1lO1xuXG5cbiAgICAgICAgY29uc3QgYm9keSA9IHtcbiAgICAgICAgICBtYXBwaW5nczoge1xuICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICBmaWVsZDE6IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmRlbGV0ZSh7XG4gICAgICAgICAgaWQ6ICdvb294eCcsXG4gICAgICAgICAgaW5kZXg6IGluZGV4LFxuICAgICAgICB9KTtcblxuXG4gICAgICAgIGNvbnNvbGUubG9nKHJlc3ApO1xuICAgICAgfSBjYXRjaCAoZXJyUmVzcCkge1xuICAgICAgICByZXNwID0gZXJyUmVzcFxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzcCB9KTtcbiAgICB9XG4gICk7XG5cbn1cbiJdfQ==